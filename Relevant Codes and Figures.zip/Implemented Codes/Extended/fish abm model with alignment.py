import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# Parameters
NUM_FISH = 100
PERCEPTION_RADIUS = 30
ATTRACTION_DIST = 10
REPULSION_DIST = 5
MAX_SPEED = 2
WIDTH, HEIGHT = 100, 100
STEPS = 100


def calculate_cohesion(fishes):
    positions = np.array([fish.position for fish in fishes])
    center_of_mass = np.mean(positions, axis=0)
    distances = np.linalg.norm(positions - center_of_mass, axis=1)
    return np.mean(distances)



class Fish:
    def __init__(self, x, y, vx, vy):
        self.position = np.array([x, y])
        self.velocity = np.array([vx, vy])
        self.speed = np.linalg.norm(self.velocity)

    def update_position(self):
        self.position += self.velocity
        # Boundary conditions
        self.position = self.position % np.array([WIDTH, HEIGHT])

    def apply_behaviors(self, fishes):
        nearest_neighbor = self.find_nearest_neighbor(fishes)
        if nearest_neighbor is not None:
            self.apply_attraction(nearest_neighbor)
            self.apply_repulsion(nearest_neighbor)
            self.apply_alignment(nearest_neighbor)

    def apply_alignment(self, nearest_neighbor):
        if nearest_neighbor is not None:
            self.velocity += (nearest_neighbor.velocity - self.velocity) / 8

            # Limiting the speed
        if np.linalg.norm(self.velocity) > MAX_SPEED:
            self.velocity = self.velocity / np.linalg.norm(self.velocity) * MAX_SPEED    
    
    
    def find_nearest_neighbor(self, fishes):
        distances = [np.linalg.norm(fish.position - self.position) for fish in fishes if fish != self]
        if distances:
            nearest_neighbor = fishes[np.argmin(distances)]
            if np.min(distances) < PERCEPTION_RADIUS:
                return nearest_neighbor
        return None

    def apply_attraction(self, neighbor):
        if np.linalg.norm(neighbor.position - self.position) > ATTRACTION_DIST:
            self.velocity += (neighbor.position - self.position) / ATTRACTION_DIST

    def apply_repulsion(self, neighbor):
        if np.linalg.norm(neighbor.position - self.position) < REPULSION_DIST:
            self.velocity -= (neighbor.position - self.position) / REPULSION_DIST

        # Limiting the speed
        if np.linalg.norm(self.velocity) > MAX_SPEED:
            self.velocity = self.velocity / np.linalg.norm(self.velocity) * MAX_SPEED
     
            


# Initialize fishes
fishes = [Fish(np.random.rand() * WIDTH, np.random.rand() * HEIGHT, np.random.randn(), np.random.randn()) for _ in range(NUM_FISH)]

cohesion_Values = []
# Update the environment
# Create initial scatter plot
fig, ax = plt.subplots()
scat = ax.scatter([fish.position[0] for fish in fishes], [fish.position[1] for fish in fishes])
ax.set_xlim(0, WIDTH)
ax.set_ylim(0, HEIGHT)
ax.set_title("Schooling Fish Simulation")

def update(frame):
    for fish in fishes:
        fish.apply_behaviors(fishes)
        fish.update_position()
        
    cohesion_Values.append(calculate_cohesion(fishes))
    
    # Update scatter plot data
    scat.set_offsets([fish.position for fish in fishes])
    return scat,

ani = animation.FuncAnimation(fig, update, frames=STEPS, blit=True, interval=20, repeat=False)
plt.show()

# Calculate and print the average cohesion metric
average_cohesion = sum(cohesion_Values) / len(cohesion_Values)
print(f"Average Cohesion Metric: {average_cohesion}")