import numpy as np
import matplotlib.pyplot as plt

# Parameters
NUM_FISH = 100
PERCEPTION_RADIUS = 30
ATTRACTION_DIST = 10
REPULSION_DIST = 5
MAX_SPEED = 2
WIDTH, HEIGHT, DEPTH = 100, 100, 100
STEPS = 100


def calculate_cohesion(fishes):
    positions = np.array([fish.position for fish in fishes])
    center_of_mass = np.mean(positions, axis=0)
    distances = np.linalg.norm(positions - center_of_mass, axis=1)
    return np.mean(distances)

def calculate_separation(fishes):
    total_separation = 0
    count = 0
    for fish in fishes:
        neighbors = fish.find_nearest_neighbors(fishes,6)
        if neighbors:
            distances = [np.linalg.norm(fish.position - n.position) for n in neighbors]
            total_separation += np.mean(distances)
            count += 1
    return total_separation / count if count > 0 else 0

def calculate_alignment(fishes):
    total_alignment = 0
    count = 0
    for fish in fishes:
        neighbors = fish.find_nearest_neighbors(fishes,6)
        if neighbors:
            average_velocity = np.mean([n.velocity for n in neighbors], axis=0)
            alignment = np.dot(fish.velocity / np.linalg.norm(fish.velocity), average_velocity / np.linalg.norm(average_velocity))
            total_alignment += alignment
            count += 1
    return total_alignment / count if count > 0 else 0



class Fish:
    def __init__(self, x, y, z, vx, vy, vz):
        self.position = np.array([x, y, z])
        self.velocity = np.array([vx, vy, vz])
        self.speed = np.linalg.norm(self.velocity)

    def update_position(self):
        self.position += self.velocity
        # Boundary conditions
        self.position = self.position % np.array([WIDTH, HEIGHT, DEPTH])

    def apply_behaviors(self, fishes):
        nearest_neighbors = self.find_nearest_neighbors(fishes, 6)
        if nearest_neighbors:
            avg_position = np.mean([n.position for n in nearest_neighbors], axis=0)
            avg_velocity = np.mean([n.velocity for n in nearest_neighbors], axis=0)
            self.apply_attraction(avg_position)
            self.apply_repulsion(avg_position)
            self.apply_alignment(avg_velocity)

    # def find_nearest_neighbor(self, fishes):
    #     distances = [np.linalg.norm(fish.position - self.position) for fish in fishes if fish != self]
    #     if distances:
    #         nearest_neighbor = fishes[np.argmin(distances)]
    #         if np.min(distances) < PERCEPTION_RADIUS:
    #             return nearest_neighbor
    #     return None

    def find_nearest_neighbors(self, fishes, number_of_neighbors):
        distances = np.array([np.linalg.norm(fish.position - self.position) for fish in fishes if fish != self])
        if len(distances) > 0:
            nearest_indices = np.argsort(distances)[:number_of_neighbors]
            return [fishes[i] for i in nearest_indices if distances[i] < PERCEPTION_RADIUS]
        return []

    def apply_attraction(self, average_position):
        if np.linalg.norm(average_position - self.position) > ATTRACTION_DIST:
            self.velocity += (average_position - self.position) / ATTRACTION_DIST
            

    def apply_repulsion(self, average_position):
        if np.linalg.norm(average_position - self.position) < REPULSION_DIST:
            self.velocity -= (average_position - self.position) / REPULSION_DIST
        # Limiting the speed
        if np.linalg.norm(self.velocity) > MAX_SPEED:
            self.velocity = self.velocity / np.linalg.norm(self.velocity) * MAX_SPEED
     
            
    def apply_alignment(self, average_velocity):
        self.velocity += (average_velocity - self.velocity) / 8
        # Limiting the speed
        # if np.linalg.norm(self.velocity) > MAX_SPEED:
        #     self.velocity = self.velocity / np.linalg.norm(self.velocity) * MAX_SPEED  


def run_simulation(num_fish):
    # Initialize the fishes
    fishes = [Fish(np.random.rand() * WIDTH, 
                   np.random.rand() * HEIGHT, 
                   np.random.rand() * DEPTH, 
                   np.random.randn(), 
                   np.random.randn(),
                   np.random.randn()) for _ in range(num_fish)]

    # Initialize lists to store metrics
    cohesion_values = []
    separation_values = []
    alignment_values = []

    # Run the simulation for a predetermined number of steps
    for _ in range(STEPS):
        for fish in fishes:
            fish.apply_behaviors(fishes)
            fish.update_position()

        # Calculate and store the metrics for this step
        cohesion_values.append(calculate_cohesion(fishes))
        separation_values.append(calculate_separation(fishes))
        alignment_values.append(calculate_alignment(fishes))

    # Calculate the average values of the metrics over all steps
    avg_cohesion = np.mean(cohesion_values)
    avg_separation = np.mean(separation_values)
    avg_alignment = np.mean(alignment_values)

    return avg_cohesion, avg_separation, avg_alignment

school_sizes = np.arange(10, 101, 10)
avg_cohesion_per_size = []
avg_separation_per_size = []
avg_alignment_per_size = []

for num_fish in school_sizes:
    all_cohesion = []
    all_separation = []
    all_alignment = []

    for run in range(10):  # Run the simulation 10 times
        avg_cohesion, avg_separation, avg_alignment = run_simulation(num_fish)
        all_cohesion.append(avg_cohesion)
        all_separation.append(avg_separation)
        all_alignment.append(avg_alignment)
        
        print(f"Completed run {run + 1}/2 for school size {num_fish}")
        
    avg_cohesion_size = np.mean(all_cohesion)
    avg_separation_size = np.mean(all_separation)
    avg_alignment_size = np.mean(all_alignment)
    

    avg_cohesion_per_size.append(np.mean(all_cohesion))
    avg_separation_per_size.append(np.mean(all_separation))
    avg_alignment_per_size.append(np.mean(all_alignment))
    
    print(f"\nSchool Size: {num_fish}")
    print(f"Average Cohesion: {avg_cohesion_size}")
    print(f"Average Separation: {avg_separation_size}")
    print(f"Average Alignment: {avg_alignment_size}")
    

    
    print(f"Completed simulations for school size {num_fish}")
    


# Plotting
plt.figure(figsize=(15, 5))

# Cohesion plot
plt.subplot(1, 3, 1)
plt.plot(school_sizes, avg_cohesion_per_size, marker='o')
plt.title('Average Cohesion vs School Size')
plt.xlabel('School Size')
plt.ylabel('Average Cohesion')

# Separation plot
plt.subplot(1, 3, 2)
plt.plot(school_sizes, avg_separation_per_size, marker='o', color='green')
plt.title('Average Separation vs School Size')
plt.xlabel('School Size')
plt.ylabel('Average Separation')

# Alignment plot
plt.subplot(1, 3, 3)
plt.plot(school_sizes, avg_alignment_per_size, marker='o', color='red')
plt.title('Average Alignment vs School Size')
plt.xlabel('School Size')
plt.ylabel('Average Alignment')

plt.tight_layout()  # Adjusts the plots to prevent overlap
plt.show()