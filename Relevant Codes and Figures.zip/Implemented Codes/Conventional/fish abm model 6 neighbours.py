import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.path as mpath
import math

def create_rotated_arrow(angle):
    # Create an arrow shape
    arrow_shape = mpath.Path.unit_regular_star(3)
    arrow_shape = mpath.Path(arrow_shape.vertices.copy(), arrow_shape.codes)  # Make a copy of the vertices
    arrow_shape.vertices *= np.array([0.6, 1])  # Scale to make it arrow-like

    # Calculate rotation matrix
    rotation_matrix = np.array([
        [np.cos(angle), -np.sin(angle)],
        [np.sin(angle), np.cos(angle)]
    ])

    # Apply rotation to the arrow vertices
    arrow_shape.vertices = np.dot(arrow_shape.vertices - arrow_shape.vertices.mean(axis=0), rotation_matrix) + arrow_shape.vertices.mean(axis=0)
    
    return arrow_shape



# Parameters
NUM_FISH = 100
PERCEPTION_RADIUS = 30
ATTRACTION_DIST = 10
REPULSION_DIST = 5
MAX_SPEED = 2
WIDTH, HEIGHT = 100, 100
STEPS = 100


def calculate_cohesion(fishes):
    positions = np.array([fish.position for fish in fishes])
    center_of_mass = np.mean(positions, axis=0)
    distances = np.linalg.norm(positions - center_of_mass, axis=1)
    return np.mean(distances)



class Fish:
    def __init__(self, x, y, vx, vy):
        self.position = np.array([x, y])
        self.velocity = np.array([vx, vy])
        self.speed = np.linalg.norm(self.velocity)

    def update_position(self):
        self.position += self.velocity
        # Boundary conditions
        self.position = self.position % np.array([WIDTH, HEIGHT])

    def apply_behaviors(self, fishes):
        nearest_neighbors = self.find_nearest_neighbors(fishes, 6)
        if nearest_neighbors:
            avg_position = np.mean([n.position for n in nearest_neighbors], axis=0)
            avg_velocity = np.mean([n.velocity for n in nearest_neighbors], axis=0)
            self.apply_attraction(avg_position)
            self.apply_repulsion(avg_position)
            self.apply_alignment(avg_velocity)

    def apply_alignment(self, average_velocity):
        self.velocity += (average_velocity - self.velocity) / 8
        # Limiting the speed
        if np.linalg.norm(self.velocity) > MAX_SPEED:
            self.velocity = self.velocity / np.linalg.norm(self.velocity) * MAX_SPEED

    def find_nearest_neighbors(self, fishes, number_of_neighbors):
        distances = np.array([np.linalg.norm(fish.position - self.position) for fish in fishes if fish != self])
        if len(distances) > 0:
            nearest_indices = np.argsort(distances)[:number_of_neighbors]
            return [fishes[i] for i in nearest_indices if distances[i] < PERCEPTION_RADIUS]
        return []

    def apply_attraction(self, average_position):
        if np.linalg.norm(average_position - self.position) > ATTRACTION_DIST:
            self.velocity += (average_position - self.position) / ATTRACTION_DIST

    def apply_repulsion(self, average_position):
        if np.linalg.norm(average_position - self.position) < REPULSION_DIST:
            self.velocity -= (average_position - self.position) / REPULSION_DIST
        # Limiting the speed
        if np.linalg.norm(self.velocity) > MAX_SPEED:
            self.velocity = self.velocity / np.linalg.norm(self.velocity) * MAX_SPEED
     
            


# Initialize fishes
fishes = [Fish(np.random.rand() * WIDTH, np.random.rand() * HEIGHT, np.random.randn(), np.random.randn()) for _ in range(NUM_FISH)]

cohesion_Values = []
# Update the environment
# Create initial scatter plot
fig, ax = plt.subplots()
initial_angles = [math.atan2(fish.velocity[1], fish.velocity[0]) for fish in fishes]
initial_paths = [create_rotated_arrow(angle) for angle in initial_angles]
scat = ax.scatter([fish.position[0] for fish in fishes], [fish.position[1] for fish in fishes], marker=initial_paths[0])
ax.set_xlim(0, WIDTH)
ax.set_ylim(0, HEIGHT)
ax.set_title("Schooling Fish Simulation")

def update(frame):
    global scat
    
    for fish in fishes:
        fish.apply_behaviors(fishes)
        fish.update_position()
        
    cohesion_Values.append(calculate_cohesion(fishes))
    
    positions = np.array([fish.position for fish in fishes])
    scat.set_offsets(positions)
    
    angles = np.array([math.atan2(fish.velocity[1], fish.velocity[0]) for fish in fishes])
    paths = [create_rotated_arrow(angle) for angle in angles]
    scat.set_paths(paths)
    return scat,

ani = animation.FuncAnimation(fig, update, frames=STEPS, blit=True, interval=20, repeat=False)
plt.show()

# Calculate and print the average cohesion metric
average_cohesion = sum(cohesion_Values) / len(cohesion_Values)
print(f"Average Cohesion Metric: {average_cohesion}")