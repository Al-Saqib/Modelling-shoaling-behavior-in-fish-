import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from mpl_toolkits.mplot3d import Axes3D

# Parameters
NUM_FISH = 100
PERCEPTION_RADIUS = 30
ATTRACTION_DIST = 10
REPULSION_DIST = 5
MAX_SPEED = 2
WIDTH, HEIGHT, DEPTH = 100, 100, 100
STEPS = 100

def calculate_cohesion(fishes):
    positions = np.array([fish.position for fish in fishes])
    center_of_mass = np.mean(positions, axis=0)
    distances = np.linalg.norm(positions - center_of_mass, axis=1)
    return np.mean(distances)

def calculate_separation(fishes):
    distances = []
    for fish in fishes:
        nearest_neighbor = fish.find_nearest_neighbor(fishes)
        if nearest_neighbor:
            distance = np.linalg.norm(fish.position - nearest_neighbor.position)
            distances.append(distance)
    return np.mean(distances) if distances else 0

def calculate_alignment(fishes):
    alignments = []
    for fish in fishes:
        nearest_neighbor = fish.find_nearest_neighbor(fishes)
        if nearest_neighbor:
            alignment = np.dot(fish.velocity / np.linalg.norm(fish.velocity),
                               nearest_neighbor.velocity / np.linalg.norm(nearest_neighbor.velocity))
            alignments.append(alignment)
    return np.mean(alignments) if alignments else 0



class Fish:
    def __init__(self, x, y, z, vx, vy, vz):
        self.position = np.array([x, y, z])
        self.velocity = np.array([vx, vy, vz])
        self.speed = np.linalg.norm(self.velocity)

    def update_position(self):
        self.position += self.velocity
        # Boundary conditions
        self.position = self.position % np.array([WIDTH, HEIGHT, DEPTH])

    def apply_behaviors(self, fishes):
        nearest_neighbor = self.find_nearest_neighbor(fishes)
        if nearest_neighbor is not None:
            self.apply_attraction(nearest_neighbor)
            self.apply_repulsion(nearest_neighbor)

    def find_nearest_neighbor(self, fishes):
        distances = [np.linalg.norm(fish.position - self.position) for fish in fishes if fish != self]
        if distances:
            nearest_neighbor = fishes[np.argmin(distances)]
            if np.min(distances) < PERCEPTION_RADIUS:
                return nearest_neighbor
        return None

    def apply_attraction(self, neighbor):
        if np.linalg.norm(neighbor.position - self.position) > ATTRACTION_DIST:
            self.velocity += (neighbor.position - self.position) / ATTRACTION_DIST

    def apply_repulsion(self, neighbor):
        if np.linalg.norm(neighbor.position - self.position) < REPULSION_DIST:
            self.velocity -= (neighbor.position - self.position) / REPULSION_DIST

        # Limiting the speed
        if np.linalg.norm(self.velocity) > MAX_SPEED:
            self.velocity = self.velocity / np.linalg.norm(self.velocity) * MAX_SPEED

# Initialize fishes
fishes = [Fish(np.random.rand() * WIDTH, 
               np.random.rand() * HEIGHT, 
               np.random.rand() * DEPTH, 
               np.random.randn(), 
               np.random.randn(),
               np.random.randn()) for _ in range(NUM_FISH)]

cohesion_Values = []
separation_values = []
alignment_values = []
# Update the environment
# Create initial scatter plot
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
scat = ax.scatter([fish.position[0] for fish in fishes], 
                  [fish.position[1] for fish in fishes],
                  [fish.position[2] for fish in fishes])
ax.set_xlim(0, WIDTH)
ax.set_ylim(0, HEIGHT)
ax.set_zlim(0, DEPTH)
ax.set_title("3D Schooling Fish Simulation")

def update(frame):
    separation_values, alignment_values, cohesion_Values
    for fish in fishes:
        fish.apply_behaviors(fishes)
        fish.update_position()
    
    cohesion_Values.append(calculate_cohesion(fishes))
    separation_values.append(calculate_separation(fishes))
    alignment_values.append(calculate_alignment(fishes))
    
    # Update scatter plot data
    scat._offsets3d = ([fish.position[0] for fish in fishes], 
                       [fish.position[1] for fish in fishes],
                       [fish.position[2] for fish in fishes])
    return scat,

ani = animation.FuncAnimation(fig, update, frames=STEPS, blit=False, interval=20, repeat=False)
plt.show()

# Calculate and print the average cohesion metric
average_cohesion = sum(cohesion_Values) / len(cohesion_Values)
print(f"Average Cohesion Metric: {average_cohesion}")

average_separation = sum(separation_values) / len(separation_values) if separation_values else 0
print(f"Average Separation Metric: {average_separation}")

# Calculate and print the average alignment metric
average_alignment = sum(alignment_values) / len(alignment_values) if alignment_values else 0
print(f"Average Alignment Metric: {average_alignment}")