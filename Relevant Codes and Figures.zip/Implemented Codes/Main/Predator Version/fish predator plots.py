import numpy as np
import matplotlib.pyplot as plt
# import matplotlib.animation as animation
# from mpl_toolkits.mplot3d import Axes3D

# Parameters
NUM_FISH = 100
PERCEPTION_RADIUS = 30
ATTRACTION_DIST = 10
REPULSION_DIST = 5
MAX_SPEED = 2
PREDATOR_PERCEPTION_RADIUS = 60
PREDATOR_MAX_SPEED = 10
WIDTH, HEIGHT, DEPTH = 100, 100, 100
STEPS = 100


def calculate_cohesion(fishes):
    positions = np.array([fish.position for fish in fishes])
    center_of_mass = np.mean(positions, axis=0)
    distances = np.linalg.norm(positions - center_of_mass, axis=1)
    return np.mean(distances)

def calculate_separation(fishes):
    distances = []
    for fish in fishes:
        nearest_neighbor = fish.find_nearest_neighbor(fishes)
        if nearest_neighbor:
            distance = np.linalg.norm(fish.position - nearest_neighbor.position)
            distances.append(distance)
    return np.mean(distances) if distances else 0

def calculate_alignment(fishes):
    alignments = []
    for fish in fishes:
        nearest_neighbor = fish.find_nearest_neighbor(fishes)
        if nearest_neighbor:
            alignment = np.dot(fish.velocity / np.linalg.norm(fish.velocity),
                               nearest_neighbor.velocity / np.linalg.norm(nearest_neighbor.velocity))
            alignments.append(alignment)
    return np.mean(alignments) if alignments else 0


class Predator3D:
    def __init__(self):
        self.position = np.random.rand(3) * np.array([WIDTH, HEIGHT, DEPTH])
        self.velocity = np.random.randn(3) * 0.5
        self.caught_fish_count = 0

    def update_position(self):
        self.position += self.velocity
        self.position = self.position % np.array([WIDTH, HEIGHT, DEPTH])

    def hunt(self, fishes):
        distances = [np.linalg.norm(fish.position - self.position) for fish in fishes]
        if distances:
            nearest_fish = fishes[np.argmin(distances)]
            distance_to_nearest = np.min(distances)
            if distance_to_nearest < PREDATOR_PERCEPTION_RADIUS:
                acceleration_vector = (nearest_fish.position - self.position) / distance_to_nearest
                self.velocity += acceleration_vector * 0.8
            # Limiting the predator's speed
                if np.linalg.norm(self.velocity) > PREDATOR_MAX_SPEED:
                    self.velocity = self.velocity / np.linalg.norm(self.velocity) * PREDATOR_MAX_SPEED
        
            if distance_to_nearest < 10:  # Predator catches the fish
                fishes.remove(nearest_fish)
                self.caught_fish_count += 1




class Fish:
    def __init__(self, x, y, z, vx, vy, vz):
        self.position = np.array([x, y, z])
        self.velocity = np.array([vx, vy, vz])
        self.speed = np.linalg.norm(self.velocity)

    def update_position(self):
        self.position += self.velocity
        # Boundary conditions
        self.position = self.position % np.array([WIDTH, HEIGHT, DEPTH])

    def apply_behaviors(self, fishes):
        nearest_neighbor = self.find_nearest_neighbor(fishes)
        if nearest_neighbor is not None:
            self.apply_attraction(nearest_neighbor)
            self.apply_repulsion(nearest_neighbor)

    def find_nearest_neighbor(self, fishes):
        distances = [np.linalg.norm(fish.position - self.position) for fish in fishes if fish != self]
        if distances:
            nearest_neighbor = fishes[np.argmin(distances)]
            if np.min(distances) < PERCEPTION_RADIUS:
                return nearest_neighbor
        return None
    
    def react_to_predator(self, predator):
        if np.linalg.norm(predator.position - self.position) < PERCEPTION_RADIUS:
            escape_direction = self.position - predator.position
            self.velocity += escape_direction / np.linalg.norm(escape_direction) * (MAX_SPEED / 3)
            if np.linalg.norm(self.velocity) > MAX_SPEED * 1.25:
                self.velocity = self.velocity / np.linalg.norm(self.velocity) * MAX_SPEED * 1.25


    def apply_attraction(self, neighbor):
        if np.linalg.norm(neighbor.position - self.position) > ATTRACTION_DIST:
            self.velocity += (neighbor.position - self.position) / ATTRACTION_DIST

    def apply_repulsion(self, neighbor):
        if np.linalg.norm(neighbor.position - self.position) < REPULSION_DIST:
            self.velocity -= (neighbor.position - self.position) / REPULSION_DIST

        # Limiting the speed
        if np.linalg.norm(self.velocity) > MAX_SPEED:
            self.velocity = self.velocity / np.linalg.norm(self.velocity) * MAX_SPEED


def run_simulation(num_fish):
    # Initialize the fishes
    fishes = [Fish(np.random.rand() * WIDTH, 
                   np.random.rand() * HEIGHT, 
                   np.random.rand() * DEPTH, 
                   np.random.randn(), 
                   np.random.randn(),
                   np.random.randn()) for _ in range(num_fish)]
    predator = Predator3D()
    
    

    # Initialize lists to store metrics
    cohesion_values = []
    separation_values = []
    alignment_values = []

    # Run the simulation for a predetermined number of steps
    for _ in range(STEPS):
        for fish in fishes:
            fish.apply_behaviors(fishes)
            fish.react_to_predator(predator)
            fish.update_position()
        
        predator.update_position()
        predator.hunt(fishes)

        # Calculate and store the metrics for this step
        cohesion_values.append(calculate_cohesion(fishes))
        separation_values.append(calculate_separation(fishes))
        alignment_values.append(calculate_alignment(fishes))

    # Calculate the average values of the metrics over all steps
    avg_cohesion = np.mean(cohesion_values)
    avg_separation = np.mean(separation_values)
    avg_alignment = np.mean(alignment_values)
    remaining_fish = len(fishes)
    caught_fish = predator.caught_fish_count

    return avg_cohesion, avg_separation, avg_alignment, remaining_fish, caught_fish

school_sizes = np.arange(10, 101, 10)
avg_cohesion_per_size = []
avg_separation_per_size = []
avg_alignment_per_size = []
avg_remaining_fish_per_size = []
avg_caught_fish_per_size = []
avg_percentage_caught_per_size = []

for num_fish in school_sizes:
    all_cohesion = []
    all_separation = []
    all_alignment = []
    all_remaining_fish = []
    all_caught_fish = []
    all_percentages_caught = []

    for run in range(10):  # Run the simulation 10 times
        avg_cohesion, avg_separation, avg_alignment, remaining_fish, caught_fish = run_simulation(num_fish)
        all_cohesion.append(avg_cohesion)
        all_separation.append(avg_separation)
        all_alignment.append(avg_alignment)
        all_remaining_fish.append(remaining_fish)
        all_caught_fish.append(caught_fish)
        percentage_caught = (caught_fish / num_fish) * 100  # Calculate percentage
        all_percentages_caught.append(percentage_caught)
        
        print(f"Completed run {run + 1}/10 for school size {num_fish}")
        
    avg_cohesion_size = np.mean(all_cohesion)
    avg_separation_size = np.mean(all_separation)
    avg_alignment_size = np.mean(all_alignment)
    avg_remaining_fish_size = np.mean(all_remaining_fish)
    avg_caught_fish_size = np.mean(all_caught_fish)
    avg_percentage_caught_size = np.mean(all_percentages_caught)
    

    avg_cohesion_per_size.append(np.mean(all_cohesion))
    avg_separation_per_size.append(np.mean(all_separation))
    avg_alignment_per_size.append(np.mean(all_alignment))
    avg_remaining_fish_per_size.append(np.mean(all_remaining_fish))
    avg_caught_fish_per_size.append(np.mean(all_caught_fish))
    avg_percentage_caught_per_size.append(avg_percentage_caught_size)
    
    
    print(f"\nSchool Size: {num_fish}")
    print(f"Average Cohesion: {avg_cohesion_size}")
    print(f"Average Separation: {avg_separation_size}")
    print(f"Average Alignment: {avg_alignment_size}")
    print(f"Average Remaining Fish: {avg_remaining_fish_size}")
    print(f"Average Caught Fish: {avg_caught_fish_size}")
    print(f"Average Percentage of Fish Caught: {avg_percentage_caught_size}")

    
    print(f"Completed simulations for school size {num_fish}")
    
    


# Plotting
plt.figure(figsize=(20, 5))

# Cohesion plot
plt.subplot(1, 3, 1)
plt.plot(school_sizes, avg_cohesion_per_size, marker='o')
plt.title('Average Cohesion vs School Size')
plt.xlabel('School Size')
plt.ylabel('Average Cohesion')

# Separation plot
plt.subplot(1, 3, 2)
plt.plot(school_sizes, avg_separation_per_size, marker='o', color='green')
plt.title('Average Separation vs School Size')
plt.xlabel('School Size')
plt.ylabel('Average Separation')

# Alignment plot
plt.subplot(1, 3, 3)
plt.plot(school_sizes, avg_alignment_per_size, marker='o', color='red')
plt.title('Average Alignment vs School Size')
plt.xlabel('School Size')
plt.ylabel('Average Alignment')

plt.tight_layout()  # Adjusts the plots to prevent overlap
plt.show()


# Plot for Average Caught Fish vs School Size
plt.figure(figsize=(10, 5))  # Adjust the figure size as needed

plt.plot(school_sizes, avg_caught_fish_per_size, marker='o', color='purple')
plt.title('Average Caught Fish vs School Size')
plt.xlabel('School Size')
plt.ylabel('Average Caught Fish')

plt.tight_layout()  # Adjusts the plot to prevent overlap
plt.show()

plt.figure(figsize=(10, 5))

plt.plot(school_sizes, avg_percentage_caught_per_size, marker='o', color='purple')
plt.title('Average Percentage of Fish Caught vs School Size')
plt.xlabel('School Size')
plt.ylabel('Average Percentage Caught')

plt.tight_layout()
plt.show()